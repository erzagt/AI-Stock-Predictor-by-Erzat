"use client"

import { useState, useRef } from "react"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import { Line } from "react-chartjs-2"
import { Download, Send, Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useTheme } from "@/components/theme-provider"

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)

// Types for our data
interface ChartData {
  dates: string[]
  prices: number[]
}

interface PredictionResult {
  prediction: string
  comment: string
  error?: string
}

export default function StockPredictor() {
  // State management
  const [tickers, setTickers] = useState<string>("AAPL,TSLA,NVDA")
  const [period, setPeriod] = useState<string>("1mo")
  const [results, setResults] = useState<Record<string, PredictionResult>>({})
  const [chartData, setChartData] = useState<Record<string, ChartData>>({})
  const [chatLog, setChatLog] = useState<string>("")
  const [userMessage, setUserMessage] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const chartRefs = useRef<Record<string, HTMLCanvasElement | null>>({})
  const { theme, setTheme } = useTheme()

  // Predict stock trends
  const predict = async () => {
    setIsLoading(true)
    const tickerList = tickers
      .toUpperCase()
      .split(",")
      .map((t) => t.trim())
    const newResults: Record<string, PredictionResult> = {}
    const newChartData: Record<string, ChartData> = {}

    for (const ticker of tickerList) {
      try {
        // Fetch prediction data
        const predRes = await fetch("/api/predict", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ticker }),
        })
        const pred = await predRes.json()

        if (pred.error || pred.prediction === "Нет данных ❌") {
          newResults[ticker] = {
            prediction: "Error",
            comment: pred.comment || pred.error || "Unknown error",
            error: true,
          }
          continue
        }

        newResults[ticker] = pred

        // Fetch chart data
        const chartRes = await fetch(`/api/chart/${ticker}?period=${period}`)
        const chartData = await chartRes.json()
        newChartData[ticker] = chartData
      } catch (e) {
        newResults[ticker] = {
          prediction: "Error",
          comment: e instanceof Error ? e.message : "Unknown error",
          error: true,
        }
      }
    }

    setResults(newResults)
    setChartData(newChartData)
    setIsLoading(false)
  }

  // Download CSV data
  const downloadCSV = () => {
    if (Object.keys(chartData).length === 0) {
      alert("No data to download. Please predict first.")
      return
    }

    let csv = "\uFEFFTicker,Date,Close Price (USD)\n"
    for (const [ticker, data] of Object.entries(chartData)) {
      if (!data.dates || !data.prices) continue
      for (let i = 0; i < data.dates.length; i++) {
        csv += `"${ticker}","${data.dates[i]}","${data.prices[i]}"\n`
      }
    }

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = "stock_data.csv"
    link.click()
  }

  // Download chart as image
  const downloadChart = (ticker: string) => {
    const canvas = chartRefs.current[ticker]
    if (!canvas) {
      alert("Chart not available")
      return
    }

    const link = document.createElement("a")
    link.href = canvas.toDataURL()
    link.download = `${ticker}_chart.png`
    link.click()
  }

  // Ask AI about stocks
  const askAI = async () => {
    if (!userMessage.trim()) return

    const newChatLog = `👤 You: ${userMessage}\n${chatLog}`
    setChatLog(newChatLog)
    setUserMessage("")

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage }),
      })
      const data = await res.json()
      setChatLog(`👤 You: ${userMessage}\n🤖 AI: ${data.response || "No response"}\n\n${chatLog}`)
    } catch (e) {
      setChatLog(`👤 You: ${userMessage}\n❌ Error: ${e instanceof Error ? e.message : "Unknown error"}\n\n${chatLog}`)
    }
  }

  // Toggle theme
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      {/* Header with theme toggle */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">📈 AI Stock Trend Predictor</h1>
        <Button variant="outline" size="icon" onClick={toggleTheme}>
          {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      {/* Input form */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div>
              <p className="mb-2">Enter stock tickers separated by commas (e.g., AAPL, TSLA, NVDA):</p>
              <div className="flex gap-2 flex-wrap">
                <Input
                  value={tickers}
                  onChange={(e) => setTickers(e.target.value)}
                  placeholder="AAPL,TSLA,NVDA"
                  className="flex-1 min-w-[200px]"
                />
                <Select value={period} onValueChange={setPeriod}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue placeholder="Period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5d">5 days</SelectItem>
                    <SelectItem value="1mo">1 month</SelectItem>
                    <SelectItem value="3mo">3 months</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={predict} disabled={isLoading}>
                  {isLoading ? "Loading..." : "Predict"}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {Object.keys(results).length > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Prediction Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(results).map(([ticker, result]) => (
                <div key={ticker} className={result.error ? "text-destructive" : ""}>
                  <span className="font-bold">{ticker}</span> → {result.prediction} | {result.comment}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Charts */}
      {Object.keys(chartData).length > 0 && (
        <div className="space-y-6 mb-6">
          {Object.entries(chartData).map(([ticker, data]) => (
            <Card key={ticker}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle>{ticker} Stock Price</CardTitle>
                <Button variant="outline" size="sm" onClick={() => downloadChart(ticker)} className="h-8">
                  <Download className="h-4 w-4 mr-2" />
                  Save Image
                </Button>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <Line
                    ref={(ref) => {
                      if (ref) {
                        chartRefs.current[ticker] = ref.canvas
                      }
                    }}
                    data={{
                      labels: data.dates,
                      datasets: [
                        {
                          label: `${ticker} Close Price`,
                          data: data.prices,
                          borderColor: theme === "dark" ? "lime" : "green",
                          backgroundColor: theme === "dark" ? "rgba(0,255,0,0.1)" : "rgba(0,128,0,0.1)",
                          tension: 0.4,
                          pointRadius: 2,
                        },
                      ],
                    }}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      scales: {
                        x: {
                          ticks: {
                            color: theme === "dark" ? "white" : "black",
                          },
                        },
                        y: {
                          ticks: {
                            color: theme === "dark" ? "white" : "black",
                          },
                        },
                      },
                      plugins: {
                        tooltip: {
                          mode: "index",
                          intersect: false,
                        },
                        legend: {
                          labels: {
                            color: theme === "dark" ? "white" : "black",
                          },
                        },
                      },
                      interaction: {
                        mode: "nearest",
                        axis: "x",
                        intersect: false,
                      },
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Download buttons */}
      {Object.keys(chartData).length > 0 && (
        <div className="flex gap-2 mb-6">
          <Button variant="outline" onClick={downloadCSV}>
            <Download className="h-4 w-4 mr-2" />
            Download CSV
          </Button>
        </div>
      )}

      {/* Chat with AI */}
      <Card>
        <CardHeader>
          <CardTitle>🤖 Chat with AI</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-2">
              <Textarea
                value={userMessage}
                onChange={(e) => setUserMessage(e.target.value)}
                placeholder="Ask a question about stocks..."
                className="flex-1"
              />
              <Button className="self-end" onClick={askAI}>
                <Send className="h-4 w-4 mr-2" />
                Send
              </Button>
            </div>
            {chatLog && (
              <div className="whitespace-pre-line p-4 bg-muted rounded-md max-h-[300px] overflow-y-auto">{chatLog}</div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
