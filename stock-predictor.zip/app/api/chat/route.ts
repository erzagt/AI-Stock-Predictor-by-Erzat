import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { message } = await request.json()

    if (!message) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 })
    }

    // In a real application, you would call an AI service here
    // For now, we'll simulate responses

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Simple keyword-based responses
    let response = "I'm not sure about that. Could you ask something about stocks or market trends?"

    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("buy") || lowerMessage.includes("invest")) {
      response =
        "Investment decisions should be based on thorough research and possibly consultation with a financial advisor. Consider factors like company fundamentals, market trends, and your risk tolerance."
    } else if (lowerMessage.includes("market") || lowerMessage.includes("trend")) {
      response =
        "Market trends are influenced by economic indicators, geopolitical events, and investor sentiment. Currently, markets are showing mixed signals with tech stocks performing differently than traditional sectors."
    } else if (lowerMessage.includes("dividend")) {
      response =
        "Dividend stocks can provide regular income. Companies with a history of consistent dividend payments are often established businesses with stable cash flows. However, high dividend yields may sometimes indicate underlying problems."
    } else if (lowerMessage.includes("risk") || lowerMessage.includes("volatile")) {
      response =
        "All investments carry risk. Diversification across different asset classes and sectors can help manage risk. Consider your investment timeline and risk tolerance when building your portfolio."
    }

    return NextResponse.json({ response })
  } catch (error) {
    console.error("Error in chat API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
