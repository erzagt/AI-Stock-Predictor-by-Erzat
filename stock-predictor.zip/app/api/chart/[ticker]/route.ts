import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { ticker: string } }) {
  try {
    const { ticker } = params
    const url = new URL(request.url)
    const period = url.searchParams.get("period") || "1mo"

    if (!ticker) {
      return NextResponse.json({ error: "Ticker is required" }, { status: 400 })
    }

    // In a real application, you would fetch actual stock data here
    // For now, we'll generate mock data

    // Generate dates for the chart
    const dates: string[] = []
    const prices: number[] = []

    const today = new Date()
    let days = 0

    switch (period) {
      case "5d":
        days = 5
        break
      case "1mo":
        days = 30
        break
      case "3mo":
        days = 90
        break
      default:
        days = 30
    }

    // Generate a starting price between $50 and $500
    let basePrice = 50 + Math.random() * 450

    // Generate data points
    for (let i = days; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(today.getDate() - i)
      dates.push(date.toISOString().split("T")[0])

      // Add some randomness to the price
      const change = (Math.random() - 0.5) * 5 // Random change between -2.5 and 2.5
      basePrice += change
      // Ensure price doesn't go below 10
      basePrice = Math.max(10, basePrice)
      prices.push(Number.parseFloat(basePrice.toFixed(2)))
    }

    return NextResponse.json({ dates, prices })
  } catch (error) {
    console.error("Error in chart API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
